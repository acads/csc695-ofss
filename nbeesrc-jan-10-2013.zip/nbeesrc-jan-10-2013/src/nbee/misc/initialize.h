/*****************************************************************************/
/*                                                                           */
/* Copyright notice: please read file license.txt in the NetBee root folder. */
/*                                                                           */
/*****************************************************************************/



int InitializeNetPDLPlugins(char *ErrBuf, int ErrBufSize);
int InitializeNetPDLInternalStructures(CNetPDLExpression *ExprHandler, CNetPDLVariables *NetPDLVariables, char *ErrBuf, int ErrBufSize);
