/*****************************************************************************/
/*                                                                           */
/* Copyright notice: please read file license.txt in the NetBee root folder. */
/*                                                                           */
/*****************************************************************************/



int LocateLibraryLocation(char* NetPDLFileLocation, int NetPDLFileLocationSize, char *ErrBuf, int ErrBufSize);
