cvmxconfig
{
	fpa CVMX_NVM_OBJ_POOL
		pool	    = 4
		size        = 16
		priority    = 1
		protected   = false
		description = "NvmObject";
}

