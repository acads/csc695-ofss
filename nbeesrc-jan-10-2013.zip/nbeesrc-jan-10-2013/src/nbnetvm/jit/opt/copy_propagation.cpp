/*****************************************************************************/
/*                                                                           */
/* Copyright notice: please read file license.txt in the NetBee root folder. */
/*                                                                           */
/*****************************************************************************/

#include "copy_propagation.h"

using namespace std;

namespace jit{
	namespace opt{

		//CopyPropagation::CopyPropagation(jit::CFG<MIRNode> > & cfg): OptimizationStep<jit::CFG<MIRNode> >(cfg) {};

	}/* OPT */
}/* JIT */
