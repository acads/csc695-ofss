This library and the related documentation can be downloaded at http://udis86.sourceforge.net/
