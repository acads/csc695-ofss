/* -----------------------------------------------------------------------------
 * udis86.h
 *
 * Copyright (c) 2004, 2005, 2006, Vivek Mohan <vivek@sig9.com>
 * All rights reserved. See LICENSE
 * -----------------------------------------------------------------------------
 */

#ifndef UDIS86_H
#define UDIS86_H

//#include <dis_types.h>
#include <extern.h>

#endif
